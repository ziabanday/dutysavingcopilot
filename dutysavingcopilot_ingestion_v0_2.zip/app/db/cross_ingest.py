
import re, argparse, datetime as dt
from typing import List, Dict, Any, Optional
import requests

from app.db.session import SessionLocal, init_db
from app.db.models import Ruling, RulingChunk
from app.core.openai_wrapper import embed
from app.core.settings import OPENAI_EMBED_MODEL
from app.utils.logging_setup import get_logger

log = get_logger("cross")

CBP_BASE = "https://rulings.cbp.gov/ruling/"

def fetch_ruling(rid: str) -> Dict[str, Any]:
    url = CBP_BASE + rid.replace(" ", "%20")
    headers = {"User-Agent": "HTS-Copilot/0.1 (dev)"}
    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()
    html = r.text

    body = re.search(r'<div[^>]*class="ruling-body"[^>]*>([\s\S]*?)</div>', html, re.I)
    text = re.sub("<[^>]+>", " ", body.group(1)) if body else html
    text = re.sub(r"\s+", " ", text).strip()
    codes = sorted(set(re.findall(r"\b(\d{4}\.\d{2}(?:\.\d{2})?)\b", text)))
    dmatch = re.search(r"(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}", html)
    rdate: Optional[dt.date] = None
    if dmatch:
        try:
            rdate = dt.datetime.strptime(dmatch.group(0), "%B %d, %Y").date()
        except Exception:
            rdate = None
    return {"ruling_id": rid, "hts_codes": codes, "url": url, "text": text, "date": rdate}

def chunk_text(text: str, target_tokens: int = 1000):
    max_chars = target_tokens * 4
    return [text[i:i+max_chars] for i in range(0, len(text), max_chars)]

def ingest_rulings(ids: List[str], chunk_version: str = "v0.1"):
    init_db()
    with SessionLocal() as s:
        for rid in ids:
            data = fetch_ruling(rid)
            r = Ruling(
                ruling_id=data["ruling_id"],
                hts_codes=data["hts_codes"],
                url=data["url"],
                text=data["text"],
                ruling_date=data["date"],
            )
            s.add(r); s.flush()
            texts = [c for c in chunk_text(data["text"], 1000) if c.strip()]
            if not texts:
                continue
            emb = embed(texts)
            vectors = [row.embedding for row in emb["response"].data]
            for idx, (txt, vec) in enumerate(zip(texts, vectors)):
                s.add(RulingChunk(
                    ruling_id_fk=r.id,
                    chunk_index=idx,
                    text=txt,
                    embedding=vec,
                    embedding_model=OPENAI_EMBED_MODEL,
                    chunk_version=chunk_version
                ))
            s.commit()
            log.info("Ingested ruling %s with %d chunks", rid, len(texts))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ids", nargs="+", required=True, help="Ruling IDs e.g. NY N123456")
    args = ap.parse_args()
    ingest_rulings(args.ids)
