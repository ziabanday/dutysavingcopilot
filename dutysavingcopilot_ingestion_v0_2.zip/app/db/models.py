
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy import Integer, String, Text, Date, BigInteger, ARRAY, ForeignKey
from typing import List, Optional

class Base(DeclarativeBase):
    pass

class HTSItem(Base):
    __tablename__ = "hts_items"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, index=True)
    description: Mapped[str] = mapped_column(Text)
    duty_rate: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    chapter: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

class Ruling(Base):
    __tablename__ = "rulings"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    ruling_id: Mapped[str] = mapped_column(String, unique=True, index=True)
    hts_codes: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String), nullable=True)
    url: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    text: Mapped[str] = mapped_column(Text)
    ruling_date: Mapped[Optional[Date]] = mapped_column(Date, nullable=True)
    chunks = relationship("RulingChunk", back_populates="ruling", cascade="all, delete-orphan")

class RulingChunk(Base):
    __tablename__ = "ruling_chunks"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    ruling_id_fk: Mapped[int] = mapped_column(ForeignKey("rulings.id", ondelete="CASCADE"), index=True)
    chunk_index: Mapped[int] = mapped_column(Integer)
    text: Mapped[str] = mapped_column(Text)
    embedding: Mapped[Optional[List[float]]] = mapped_column()  # pgvector in prod; null in sqlite
    embedding_model: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    chunk_version: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    ruling = relationship("Ruling", back_populates="chunks")
